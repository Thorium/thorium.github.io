﻿    module MyStartUp

    open Owin
    open Microsoft.AspNet.SignalR

    let hubConfig = HubConfiguration(EnableDetailedErrors = true, EnableJavaScriptProxies = true)

    type MyWebStartup() =
        member x.Configuration(app:Owin.IAppBuilder) =
            //OWIN Component registrations here...

            //SignalR:
            app.MapSignalR(hubConfig) |> ignore            

            //Static files server (Note: default FileSystem is current directory!)
            let fileServerOptions = Microsoft.Owin.StaticFiles.FileServerOptions()
            fileServerOptions.DefaultFilesOptions.DefaultFileNames.Add("index.html")
            //fileServerOptions.FileSystem <- Microsoft.Owin.FileSystems.PhysicalFileSystem(@"c:\wwwroot\")
            app.UseFileServer fileServerOptions
            |> ignore

            ()

    [<assembly: Microsoft.Owin.OwinStartup(typeof<MyWebStartup>)>]
    do()

